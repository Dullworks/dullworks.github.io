Cookie Box Planner v1 (Dullworks)

1. Unzip this folder.
2. Double-click cookie-box-planner.html. It opens in your web browser and works offline.
3. Read quick-start.pdf for the steps.

Your plan saves in the browser on this device. Download a backup from the "Save & backup" tab now and then.

File won't open or download? Email dullworks@agentmail.to and we'll send it again.

Digital download. All sales are final, no refunds.
