two-parent christmas gift tracker / v1.0
dullworks

START: unzip the download, read setup-guide.pdf, and copy the blank workbook.
Files:
- two-parent-gift-tracker-blank.xlsx
- two-parent-gift-tracker-fictional-example.xlsx (all people and stores fictional)
- setup-guide.pdf (3 pages)
- README.txt

Macro-free. 300 gift rows, 200 order rows, 8 kids, 40 other recipients, 2 adults.
Tested by recalculation in LibreOffice; not directly tested in Excel or Google Sheets.
Built with Sheets-compatible functions. After importing, check dropdowns, dates,
totals and print settings. Google Sheets: File > Import > Upload.
Excel: File > Open. No macros need enabling.

Count = one non-stocking gift row with an item and a non-idea, nonblank status.
Spend = actual costs entered, regardless of status. Summary includes stockings.
Orders & Returns is separate; it never adds spending or gifts.
Blue/white rows are editable inputs; green formula panels are read-only by convention.
Formulas are not password protected. Use unique recipient names and existing rows.
One currency per file, displayed as USD. Deadlines are manual reminders, not alerts.
Hiding spots are visible to anyone with workbook access. Keep backups.
Recordkeeping only, no financial advice.

For personal household use. Do not resell or redistribute this template.
File won't open or download? Email dullworks@agentmail.to and we'll send it again.
Digital download. All sales are final, no refunds.
