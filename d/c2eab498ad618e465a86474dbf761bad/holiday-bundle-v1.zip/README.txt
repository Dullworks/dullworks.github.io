Dullworks Holiday Bundle v1
Two-Parent Christmas Gift Tracker + Cookie Box Planner

What's inside
- two-parent-gift-tracker/  blank and fictional-example .xlsx workbooks (no macros), setup-guide.pdf, README.txt
- cookie-box-planner/       cookie-box-planner.html (one offline file), quick-start.pdf, README.txt

How to start
1. Unzip this folder.
2. Gift tracker: read setup-guide.pdf, then make a copy of the blank workbook.
3. Cookie planner: double-click cookie-box-planner.html. It opens in your browser and works offline. quick-start.pdf has the steps.

Compatibility, as tested
- Gift tracker: tested in LibreOffice. Built with functions Excel and Google Sheets support, but not tested directly in either.
- Cookie planner: tested in Chrome. It saves in your browser on that device; download a backup now and then.

Recordkeeping and planning only. No financial or food-safety advice.
For personal household use. Do not resell or redistribute.
File won't open or download? Email dullworks@agentmail.to and we'll send it again.

Digital download. All sales are final, no refunds.
