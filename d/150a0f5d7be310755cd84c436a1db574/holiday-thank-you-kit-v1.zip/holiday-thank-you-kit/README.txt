Holiday Thank-You Kit v1 (Dullworks)

1. Unzip this folder.
2. Double-click thank-you-kit.html. It opens in your web browser and works offline, with no account.
3. Read quick-start.pdf for the steps.

Prefer paper? Print thank-you-kit-printables-letter.pdf (US Letter) or thank-you-kit-printables-a4.pdf (A4). Choose Actual size or 100% when you print.

Your list saves in the browser on this device. Download a backup from the "Save and backup" tab now and then.

File will not open or download? Email dullworks@agentmail.to and we will send it again.

Digital download. All sales are final, no refunds.
