Leftover-First Weekly Meal Planner v1 (Dullworks)

1. Unzip this folder.
2. Double-click leftover-first-meal-planner.html. It opens in your web browser and works offline, with no account.
3. Read quick-start.pdf for the steps.

Prefer paper? Print leftover-first-printables-letter.pdf (US Letter) or leftover-first-printables-a4.pdf (A4). Choose Actual size or 100% when you print.

Your recipes, plan and list save in the browser on this device. Download a backup from the Save and backup tab now and then.

File will not open or download? Email dullworks@agentmail.to and we will send it again.

Digital download. All sales are final, no refunds.
