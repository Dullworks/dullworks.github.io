Christmas Morning Gift Hunt v1 (Dullworks)

1. Unzip this folder.
2. Double-click gift-hunt-builder.html. It opens in your web browser and works offline.
3. Read quick-start.pdf for the steps.

Short on time? Print the ready-made set instead: gift-hunt-printables-letter.pdf (US Letter) or gift-hunt-printables-a4.pdf (A4). It has 4 trails of 8 cards, blank cards, a hide sheet, an answer key and certificates.

Your hunt saves in the browser on this device. Download a backup from the "Save and backup" tab now and then.

File will not open or download? Email dullworks@agentmail.to and we will send it again.

Digital download. All sales are final, no refunds.
