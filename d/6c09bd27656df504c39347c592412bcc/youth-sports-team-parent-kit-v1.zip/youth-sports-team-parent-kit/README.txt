Youth Sports Team-Parent Kit v1 (Dullworks)

1. Unzip this folder.
2. Double-click team-parent-kit.html. It opens in your web browser and works offline, with no account.
3. Read quick-start.pdf for the steps.

Prefer paper? Print team-parent-printables-letter.pdf (US Letter) or team-parent-printables-a4.pdf (A4). Choose Actual size or 100% when you print.

Your team list saves in the browser on this device. Download a backup from the Save and backup tab now and then.

File will not open or download? Email dullworks@agentmail.to and we will send it again.

Digital download. All sales are final, no refunds.
